from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from jose import JWTError, jwt
import pyodbc
import uvicorn


app = FastAPI()
security = HTTPBearer()

# Configuración del secreto JWT
SECRET_KEY = "tu_secreto_aqui"
ALGORITHM = "HS256"

conn_str = 'DRIVER={SQL Server};SERVER=tu_servidor;DATABASE=tu_base_de_datos;UID=tu_usuario;PWD=tu_contraseña'

# Modelo para los datos de autenticación
class Token(BaseModel):
    access_token: str
    token_type: str

# Función para generar un token JWT
def create_token(username: str, password: str) -> str:
    # Verificar las credenciales en la base de datos o sistema de almacenamiento
    
    # Aquí, se asume que existe una tabla "Users" en la base de datos, donde se almacenan los usuarios y contraseñas
    conn = get_db_connection()
    cursor = conn.cursor()
    query = "SELECT password FROM Users WHERE username = ?"
    cursor.execute(query, username)
    row = cursor.fetchone()
    stored_password = row.password if row else None

    if stored_password is not None and password == stored_password:
        # Credenciales válidas, generar el token JWT
        payload = {"username": username}
        access_token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
        return access_token
    
    # Credenciales inválidas, retornar None o levantar una excepción
    return None

def get_db_connection():
    conn = pyodbc.connect(conn_str)
    return conn
@app.get("/users")
def get_users():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Users")
    rows = cursor.fetchall()

    users = []
    for row in rows:
        user = {
            "id": row.id,
            "username": row.username,
            "email": row.email
        }
        users.append(user)

    return {"users": users}

# Ruta para autenticar y obtener un token JWT
@app.post("/login")
async def login(username: str, password: str):
    # Realiza aquí la lógica de autenticación, verificación de credenciales, etc.
    # Si la autenticación es exitosa, se genera el token JWT

    access_token = create_token(username, password)
    token_type = "bearer"

    return {"access_token": access_token, "token_type": token_type}

# Ruta protegida con autenticación JWT
@app.get("/protected")
async def protected_route(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        # Verifica el token JWT recibido
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("username")
        if username is None:
            raise JWTError("Invalid token")
        
        # Realiza aquí la lógica para la ruta protegida

        return {"message": f"Hello, {username}! This is a protected route."}
    
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
