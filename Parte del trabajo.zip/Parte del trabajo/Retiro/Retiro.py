from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from pydantic import BaseModel
import pyodbc

app = FastAPI()
security = HTTPBearer()

# Configuración del secreto JWT
SECRET_KEY = "tu_secreto_aqui"
ALGORITHM = "HS256"

# Configuración de la conexión a la base de datos SQL Server
conn_str = 'DRIVER={SQL Server};SERVER=tu_servidor;DATABASE=tu_base_de_datos;UID=tu_usuario;PWD=tu_contraseña'

# Modelo para los datos de autenticación
class Token(BaseModel):
    access_token: str
    token_type: str

# Función para generar un token JWT
def create_token(username: str, password: str) -> str:
    # Realiza aquí la lógica de autenticación, verificación de credenciales, etc.
    # Si la autenticación es exitosa, puedes generar el token JWT

    # Aquí se incluye la lógica de autenticación y generación del token JWT
    payload = {"username": username}
    access_token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    
    return access_token

# Función para obtener la conexión a la base de datos
def get_db_connection():
    conn = pyodbc.connect(conn_str)
    return conn

# Ruta para servir el archivo HTML
@app.get("/")
async def get_html():
    return {"html": "static/index.html"}

# Ruta para recibir el texto ingresado
@app.post("/texto")
async def recibir_texto(texto: str, credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        # Verifica el token JWT recibido
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("username")
        if username is None:
            raise JWTError("Invalid token")
        
        # Realiza aquí la lógica para procesar el texto ingresado
        print("Texto ingresado:", texto)

        # Realiza aquí la lógica de la base de datos (ejemplo: insertar el texto en una tabla)
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Textos (texto) VALUES (?)", texto)
        conn.commit()

        return {"message": "Texto recibido correctamente"}
    
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
