from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from pydantic import BaseModel
import pyodbc

app = FastAPI()
security = HTTPBearer()

# Configuración del secreto JWT
SECRET_KEY = "tu_secreto_aqui"
ALGORITHM = "HS256"

conn_str = 'DRIVER={SQL Server};SERVER=tu_servidor;DATABASE=tu_base_de_datos;UID=tu_usuario;PWD=tu_contraseña'

# Modelo para los datos de autenticación
class Token(BaseModel):
    access_token: str
    token_type: str

# Función para generar un token JWT
def create_token(username: str, password: str) -> str:
    # Realiza aquí la lógica de autenticación, verificación de credenciales, etc.
    # Si la autenticación es exitosa, puedes generar el token JWT

    # Aquí se incluye la lógica de autenticación y generación del token JWT
    payload = {"username": username}
    access_token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    
    return access_token

# Función para obtener la conexión a la base de datos
def get_db_connection():
    conn = pyodbc.connect(conn_str)
    return conn

@app.get("/protected")
async def protected_route(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        # Verifica el token JWT recibido
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("username")
        if username is None:
            raise JWTError("Invalid token")
        
        # Realiza aquí la lógica para la ruta protegida
        
        # Ejemplo de conexión a la base de datos
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tabla")
        result = cursor.fetchall()
        
        # Procesa el resultado de la consulta
        
        return {"message": f"Hello, {username}! This is a protected route.", "data": result}
    
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
