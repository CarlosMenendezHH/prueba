from fastapi import FastAPI, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import HTMLResponse
from jose import JWTError, jwt
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

app = FastAPI()
security = HTTPBearer()

# Configuración de la base de datos SQL Server
SQLALCHEMY_DATABASE_URL = "mssql+pyodbc://<Poco1>:<Family4aG>@<server>/<database>?driver=SQL+Server"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Modelo de usuario para la autenticación JWT
class User(BaseModel):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True)
    password = Column(String)

# Clave secreta para la firma y verificación del JWT
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"

# Función para obtener una instancia de sesión de la base de datos
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Función para verificar y decodificar el token JWT
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        return username
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Ruta protegida con autenticación JWT
@app.get("/", response_class=HTMLResponse, tags=["protected"])
async def read_html(current_user: str = Depends(get_current_user)):
    html_content = """
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Asignación de Materias y Horarios a Docentes</title>
      <style>
        body {
          background-color: #635985;
          color: #fff;
          font-family: Arial, sans-serif;
        }
        
        h1 {
          color: #443C68;
        }
        
        table {
          width: 100%;
          border-collapse: collapse;
        }
        
        th, td {
          padding: 10px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        
        th {
          background-color: #393053;
        }
        
        #boton-retroceso {
          background-color: #443C68;
          color: #fff;
          padding: 10px 20px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          margin-bottom: 20px;
        }
      </style>
    </head>
    <body>
      <button id="boton-retroceso" onclick="retroceder()">Retroceder</button>
      
      <h1>Asignación de Materias y Horarios a Docentes</h1>
      
      <table>
        <thead>
          <tr>
            <th>Docente</th>
            <th>Materia</th>
            <th>Horario</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Docente 1</td>
            <td>Materia A</td>
            <td>Lunes 9:00 - 11:00</td>
          </tr>
          <tr>
            <td>Docente 2</td>
            <td>Materia B</td>
            <td>Martes 14:00 - 16:00</td>
          </tr>
          <tr>
            <td>Docente 3</td>
            <td>Materia C</td>
            <td>Miércoles 10:00 - 12:00</td>
          </tr>
          <tr>
            <td>Docente 4</td>
            <td>Materia D</td>
            <td>Jueves 9:00 - 11:00</td>
          </tr>
          <tr>
            <td>Docente 5</td>
            <td>Materia E</td>
            <td>Viernes 14:00 - 16:00</td>
          </tr>
          <tr>
            <td>Docente 6</td>
            <td>Materia F</td>
            <td>Sábado 10:00 - 12:00</td>
          </tr>
          <!-- Agrega más filas según sea necesario -->
        </tbody>
      </table>
      
      <script>
        function retroceder() {
          window.history.back();
        }
      </script>
    </body>
    </html>
    """
    return html_content

# Ruta para obtener un token JWT de autenticación
@app.post("/login", tags=["authentication"])
async def login(username: str, password: str, db=Depends(get_db)):
    user = db.query(User).filter(User.username == username).first()
    if not user or user.password != password:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = jwt.encode({"sub": user.username}, SECRET_KEY, algorithm=ALGORITHM)
    return {"token": token}

# Ruta para verificar el estado de la API
@app.get("/status")
async def get_status():
    return {"status": "API is running"}

# Ruta para realizar alguna otra operación protegida con autenticación JWT
@app.get("/operation")
async def perform_operation(current_user: str = Depends(get_current_user)):
    # Realizar alguna operación protegida aquí
    return {"message": "Operation performed successfully"}

import uvicorn

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
