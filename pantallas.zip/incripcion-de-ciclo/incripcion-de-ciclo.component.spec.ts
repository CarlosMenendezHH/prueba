import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncripcionDeCicloComponent } from './incripcion-de-ciclo.component';

describe('IncripcionDeCicloComponent', () => {
  let component: IncripcionDeCicloComponent;
  let fixture: ComponentFixture<IncripcionDeCicloComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IncripcionDeCicloComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IncripcionDeCicloComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
