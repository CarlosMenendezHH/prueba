import { Component } from '@angular/core';

@Component({
  selector: 'app-incripcion-de-ciclo',
  templateUrl: './incripcion-de-ciclo.component.html',
  styleUrls: ['./incripcion-de-ciclo.component.css']
})
export class IncripcionDeCicloComponent {

}
