import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaDeHorariosAsignadosComponent } from './consulta-de-horarios-asignados.component';

describe('ConsultaDeHorariosAsignadosComponent', () => {
  let component: ConsultaDeHorariosAsignadosComponent;
  let fixture: ComponentFixture<ConsultaDeHorariosAsignadosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsultaDeHorariosAsignadosComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsultaDeHorariosAsignadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
