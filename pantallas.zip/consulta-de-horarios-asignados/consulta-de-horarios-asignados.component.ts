import { Component } from '@angular/core';

@Component({
  selector: 'app-consulta-de-horarios-asignados',
  templateUrl: './consulta-de-horarios-asignados.component.html',
  styleUrls: ['./consulta-de-horarios-asignados.component.css']
})
export class ConsultaDeHorariosAsignadosComponent {

}
