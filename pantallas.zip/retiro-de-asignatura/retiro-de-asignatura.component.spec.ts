import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetiroDeAsignaturaComponent } from './retiro-de-asignatura.component';

describe('RetiroDeAsignaturaComponent', () => {
  let component: RetiroDeAsignaturaComponent;
  let fixture: ComponentFixture<RetiroDeAsignaturaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RetiroDeAsignaturaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RetiroDeAsignaturaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
