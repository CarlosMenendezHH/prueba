import { Component } from '@angular/core';

@Component({
  selector: 'app-retiro-de-asignatura',
  templateUrl: './retiro-de-asignatura.component.html',
  styleUrls: ['./retiro-de-asignatura.component.css']
})
export class RetiroDeAsignaturaComponent {

}
